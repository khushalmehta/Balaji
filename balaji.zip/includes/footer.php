<footer class="footer-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-3">
        <div class="footer-left">
          <div class="footer-logo">
            <a href="index.php" class="logo me-auto"><img src="img/shreeBalajiEnterprises.png" class="img-fluid"  alt=""></a>
          </div>
          <ul>
            <li>With the progressive approach and farsightedness of our mentor<br>
            <b>  Mr. Parmanand Sharma</b>,<br> we have successfully created several benchmarks
              in the industry...</li>
              <button type="button" class="btn btn-outline-warning btn-sm">Read More</button>
            <!-- <li>Phone: +65 11.188.888</li>
            <li>Email: <a href="https://preview.colorlib.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="93fbf6fffffcbdf0fcfffce1fffaf1d3f4fef2faffbdf0fcfe">[email&#160;protected]</a></li>
          </ul>
          <div class="footer-social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-pinterest"></i></a>
          </div> -->
        </div>
      </div>
      <div class="col-lg-2 offset-lg-1">
        <div class="footer-widget">
          <h5>Support</h5>
          <ul>
            <li><a href="contact.php">Contact Us<hr style="margin:0;border: 0.8px solid #e7ab3c; width: 55%;"></a></li>
            <li><a href="faq.php">FAQ's<hr style="margin:0;border: 0.8px solid #e7ab3c; width: 55%;"></a></li>
            <li><a href="broucher.php?file=shree-balaji-enterprises" target="_blank">Broucher<hr style="margin:0;border: 0.8px solid #e7ab3c; width: 55%;"></a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-2">
        <div class="footer-widget">
          <h5>Quick Links</h5>
          <ul>
            <li><a href="index.php">Home<hr style="margin:0;border: 0.8px solid #e7ab3c; width: 55%;"></a></li>
            <li><a href="about.php">About<hr style="margin:0;border: 0.8px solid #e7ab3c;width: 55%;"></a></li>
            <li><a href="products.php?pcategory=all">All Products<hr style="margin:0;border: 0.8px solid #e7ab3c;width: 55%;"></a></li>
            <li><a href="blog.php">Blog<hr style="margin:0;border: 0.8px solid #e7ab3c;width: 55%;"></a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="newslatter-item">
          <h5>Location:</h5>
          <a target="_blank" href="https://goo.gl/maps/XhgVt8AtfB1PanV48"><i id="icon-contact" class="fa fa-map-marker" aria-hidden="true"></i>
          <p> Shree Balaji Enterprises, Magarpatta,<br>
             Hadapsar, Pune - 411028,<br>
              Maharashtra, India</p></a>
          <h5>Contact No.:</h5>
          <a target="_blank" href="tel:+918041947127"><i id="icon-contact" class="fa fa-phone-square" aria-hidden="true"></i>
            <p>+91 8041947127</p></a>
          <h5>Email Id:</h5>
          <a target="_blank" href="#"><i id="icon-contact" class="fa fa-envelope" aria-hidden="true"></i>
           <p>email@shreebalajienterprises.com</p></a>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright-reserved">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="copyright-text">

            Copyright &copy;<?php echo date("Y"); ?>
           All rights reserved | Designed & Developed by <a href="admin/login.php"><i class="fa fa-cube" aria-hidden="true"></i></a>
           <a href="https://www.hspmsolutions.com/" ><b>HSPM Solutions LLP</b></a>

          </div>
          <div class="payment-pic">
            <a  id="social-links" target="_blank" onclick="_gaq.push(['b._trackEvent','Bottom','facebook','d0055'])" href="https://www.facebook.com/sharer.php?u=https://www.shreebalajienterprises.org/"  class="facebook"><i class="fa fa-facebook"></i></a>
            <a  id="social-links" target="_blank" onclick="_gaq.push(['b._trackEvent','Bottom','gmail','d0055'])" href=""  class="google-plus"><i class="fa fa-envelope-o"></i></a>
            <a  id="social-links" target="_blank" onclick="_gaq.push(['b._trackEvent','Bottom','twitter','d0055'])" href="https://twitter.com/share?url=https://www.shreebalajienterprises.org/&amp;text=Shree Balaji Enterprises" class="twitter"><i class="fa fa-twitter"></i></a>
            <a  id="social-links" target="_blank" onclick="_gaq.push(['b._trackEvent','Bottom','linkedin','d0055'])" href="https://www.linkedin.com/cws/share?url=https://www.shreebalajienterprises.org/" class="linkedin"><i class="fa fa-linkedin"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
